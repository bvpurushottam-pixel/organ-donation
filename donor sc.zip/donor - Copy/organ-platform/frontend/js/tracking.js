let socket = io()

socket.on("trackingUpdate", status => {
  let steps = document.querySelectorAll("#track li")
  steps.forEach((el, i) => {
    if (i <= status) el.style.fontWeight = "bold"
  })
})
