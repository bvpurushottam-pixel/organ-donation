document.getElementById("donorForm").onsubmit = (e) => {
  e.preventDefault()

  const data = {
    name: e.target.name.value,
    age: e.target.age.value,
    blood: e.target.blood.value,
    organs: [...document.querySelectorAll("input[name='organs']:checked")].map(x => x.value),
    history: e.target.history.value,
    nominee: e.target.nominee.value,
    status: "Consent Pending"
  }

  fetch("/api/donor", {
    method: "POST",
    headers: {"Content-Type": "application/json"},
    body: JSON.stringify(data)
  }).then(res => res.json())
    .then(x => {
      alert("Donor Registered")
      location.href = "consent.html"
    })
}
