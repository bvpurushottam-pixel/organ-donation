const express = require("express");
const app = express();
const fs = require("fs");
const http = require("http").Server(app);
const io = require("socket.io")(http);
const bodyParser = require("body-parser");
const cors = require("cors");

app.use(cors());
app.use(bodyParser.json());
app.use(express.static("frontend"));

// Load donors DB (JSON file)
let donors = JSON.parse(fs.readFileSync("./data/donors.json"));

// Register Donor
app.post("/api/donor", (req, res) => {
  const donor = req.body;
  donor.id = Date.now();
  donors.push(donor);
  fs.writeFileSync("./data/donors.json", JSON.stringify(donors, null, 2));
  res.json({ msg: "Donor Registered", donor });
});

// Hospital filter
app.get("/api/donors", (req, res) => {
  let result = donors;
  if (req.query.blood) result = result.filter(d => d.blood === req.query.blood);
  if (req.query.organ) result = result.filter(d => d.organs.includes(req.query.organ));
  res.json(result);
});

// Dummy PDF Consent generator placeholder
app.post("/api/consent", (req, res) => {
  res.json({ msg: "Consent PDF Generated (placeholder)" });
});

// Real-time tracking using socket.io
io.on("connection", socket => {
  console.log("Hospital connected for tracking");

  socket.on("updateTracking", status => {
    io.emit("trackingUpdate", status);
  });
});

http.listen(3000, () => {
  console.log("Server running on http://localhost:3000");
});
